/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.anobissextomaven;

/**
 *
 * @author User
 */
public class AnoBissextoEsqueleto {
    
    public boolean anoBissexto(int anoBissexto){
        
        if(anoBissexto > 0){
        if (anoBissexto % 400 == 0){
            System.out.println("O ano é bissexto! "+ anoBissexto);
               return true;
                
        } else if (anoBissexto % 4 == 0){
            System.out.println("O ano é bissexto! "+ anoBissexto);
                return true;
               
        } else System.out.println("O ano não é bissexto "+ anoBissexto);
        
        return false;

        } else System.out.println("O ano não é bissexto "+ anoBissexto);
        return false;
    }
}
